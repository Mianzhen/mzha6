package com.example.peter.myapplication;

import java.util.ArrayList;

/**
 * Created by peter on 2016/11/23.
 */

public class Question {
    private String title;
    private ArrayList<String> selections;

    public Question(String question, ArrayList selections) {
        this.title = question;
        this.selections = selections;
    }

    public String getTitle() {
        return title;
    }

    public ArrayList<String> getSelection() {
        return selections;
    }
}
