package com.example.peter.myapplication;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.litepal.crud.DataSupport;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class QuestionActivity extends AppCompatActivity {

    private ArrayList<Question> questions = new ArrayList<>();
    private ArrayList<String> answers = new ArrayList<>();
    private ArrayList<QuestionAdapter> adapters = new ArrayList<>();

    int num = 0;

    TextView textQuestion;
    ListView listViewSelection;
    TextView textLast;
    TextView textCount;

    Dialog alertDialog;
    Dialog waitDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);

        View v = findViewById(R.id.question_background);
        v.getBackground().setAlpha(120);

        StatusBarUtils.setWindowStatusBarColor(QuestionActivity.this, R.color.colorPrimary);

        questionInit();
        adapterInit();

        textQuestion = (TextView) findViewById(R.id.text_title);
        listViewSelection = (ListView) findViewById(R.id.list_view_selection);
        textLast = (TextView) findViewById(R.id.text_back);

        listViewSelection.setOnItemClickListener(selectionOnItemClickListener);
        textLast.setOnClickListener(textLastOnClickListener);

        textQuestion.setText(questions.get(num).getTitle());
        listViewSelection.setAdapter(adapters.get(num));
        textLast.setVisibility(View.INVISIBLE);

        textCount = (TextView) findViewById(R.id.text_count);
        textCount.setText("1/10");

        alertDialog = new AlertDialog.Builder(this).
                setTitle("Warning").
                setMessage("Please Choose different Answer!").
                setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // TODO Auto-generated method stub
                        dialog.dismiss();
                    }
                }).
                create();

        waitDialog = new AlertDialog.Builder(this).
                setTitle("Processing...").
                setMessage("Processing...").
                create();
    }

    private AdapterView.OnItemClickListener selectionOnItemClickListener = new AdapterView.OnItemClickListener() {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            String answer = questions.get(num).getSelection().get(position);

            answers.add(answer);
            num++;
            if(num == questions.size() ) {
                //TODO
                Intent intent = new Intent(QuestionActivity.this, ResultActivity.class);

                Algorithm algorithm = new Algorithm();
                ArrayList<Integer> temp = algorithm.run(answers, getApplicationContext());

                intent.putExtra("recommend_result", temp);

                FileOutputStream out;
                BufferedWriter writer;
                try {
                    out = openFileOutput("record.txt", Context.MODE_PRIVATE);
                    writer = new BufferedWriter(new OutputStreamWriter(out));
                    for(int i = 0; i < 10; i++)
                        writer.write(temp.get(i));
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                startActivity(intent);
                finish();
                return;
            }
            textQuestion.setText(questions.get(num).getTitle());
            listViewSelection.setAdapter(adapters.get(num));
            textLast.setVisibility(View.VISIBLE);
            textCount.setText((num + 1) + "/10");
        }
    };

    private View.OnClickListener textLastOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            answers.remove(answers.size() - 1);
            if(--num == 0)
                textLast.setVisibility(View.INVISIBLE);
            textQuestion.setText(questions.get(num).getTitle());
            listViewSelection.setAdapter(adapters.get(num));
            textCount.setText((num + 1) + "/10");
        }
    };

    private void questionInit() {
        String title;
        ArrayList<String> selections;

        title = "1 What is your intended major?";
        selections = new ArrayList<>();
        selections.add("A:Business");
        selections.add("B:Engineering");
        selections.add("C:Biological science");
        selections.add("D:Physics");
        selections.add("E:Chemistry");
        selections.add("F:Mathematics");
        selections.add("G:Statistics");
        selections.add("H:Computer science");
        selections.add("I:Law");
        selections.add("J:Medicine");
        selections.add("K:Education");
        selections.add("L:Public affair");
        selections.add("M:English");
        selections.add("N:Political science");
        selections.add("O:Economics");
        selections.add("P:Psychology");
        selections.add("Q:History");
        selections.add("R:Sociology");

        Question q1 = new Question(title, selections);
        questions.add(q1);

        title = "2 What level of schools are you targeting?";
        selections = new ArrayList<>();
        selections.add("A:Top 10");
        selections.add("B:20-30");
        selections.add("C:30-50");
        selections.add("D:50-100");

        Question q2 = new Question(title, selections);
        questions.add(q2);

        title = "3 What's your GPA in high school?";
        selections = new ArrayList<>();
        selections.add("A:4.0");
        selections.add("B:3.9");
        selections.add("C:3.8");
        selections.add("D:3.7");
        selections.add("E:3.6");
        selections.add("F:3.5");
        selections.add("G:3.4");
        selections.add("H:3.3");
        selections.add("I:3.2");
        selections.add("J:3.1");
        selections.add("K:3.0");
        selections.add("L:less than 3.0");

        Question q3 = new Question(title, selections);
        questions.add(q3);

        title = "4 What's your SAT score?";
        selections = new ArrayList<>();
        selections.add("A:higher than 1550");
        selections.add("B:1500-1550");
        selections.add("C:1450-1500");
        selections.add("D:1400-1450");
        selections.add("E:1350-1400");
        selections.add("F:1300-1350");
        selections.add("G:1250-1300");
        selections.add("H:1200-1250");
        selections.add("I:1150-1200");
        selections.add("J:1100-1150");
        selections.add("K:1050-1100");
        selections.add("L:1000-1050");
        selections.add("M:Less than 1000");

        Question q4 = new Question(title, selections);
        questions.add(q4);

        title = "5 What's your TOEFL score?";
        selections = new ArrayList<>();
        selections.add("A:Higher than 115");
        selections.add("B:110-115");
        selections.add("C:105-110");
        selections.add("D:100-105");
        selections.add("E:95-100");
        selections.add("F:90-95");
        selections.add("G:85-90");
        selections.add("H:80-85");
        selections.add("I:75-80");
        selections.add("J:70-75");
        selections.add("K:65-70");
        selections.add("L:60-65");
        selections.add("M:Less than 60");

        Question q5 = new Question(title, selections);
        questions.add(q5);

        title = "6 The level of tuition you think is appropriate?";
        selections = new ArrayList<>();
        selections.add("A:Less than $15,000");
        selections.add("B:$15,000-$20,000");
        selections.add("C:$20,000-$25,000");
        selections.add("D:$25,000-$30,000");
        selections.add("E:$30,000-$35,000");
        selections.add("F:$35,000-$40,000");
        selections.add("G:More than $40,000");

        Question q6 = new Question(title, selections);
        questions.add(q6);

        title = "7 The diversity of races?";
        selections = new ArrayList<>();
        selections.add("A:I prefer more diversity among students");
        selections.add("B:I prefer less diversity among students");
        selections.add("C:I don't care");

        Question q7 = new Question(title, selections);
        questions.add(q7);

        title = "8 Which region do you prefer?";
        selections = new ArrayList<>();
        /*
        selections.add("AA-AK");
        selections.add("AB-AL");
        selections.add("AC-AR");
        selections.add("AD-AZ");
        selections.add("AE-CA");
        selections.add("AF-CO");
        selections.add("AG-CT");
        selections.add("AH-DC");
        selections.add("AI-DE");
        selections.add("AJ-FL");

        selections.add("AK-GA");
        selections.add("AL-HI");
        selections.add("AM-IA");
        selections.add("AN-ID");
        selections.add("AO-IL");
        selections.add("AP-IN");
        selections.add("AQ-KS");
        selections.add("AR-KY");
        selections.add("AS-LA");
        selections.add("AT-MA");

        selections.add("AU-MD");
        selections.add("AV-ME");
        selections.add("AW-MI");
        selections.add("AX-MN");
        selections.add("AY-MO");
        selections.add("AZ-MS");
        selections.add("BA-MT");
        selections.add("BB-NC");
        selections.add("BC-ND");
        selections.add("BD-NE");

        selections.add("BE-NH");
        selections.add("BF-NJ");
        selections.add("BG-NM");
        selections.add("BH-NV");
        selections.add("BI-NY");
        selections.add("BJ-OH");
        selections.add("BK-OK");
        selections.add("BL-OR");
        selections.add("BM-PA");
        selections.add("BN-RI");

        selections.add("BO-SC");
        selections.add("BP-SD");
        selections.add("BQ-TN");
        selections.add("BR-TX");
        selections.add("BS-UT");
        selections.add("BT-VA");
        selections.add("BU-WA");
        selections.add("BV-WI");
        selections.add("BW-WV");
        selections.add("BX-WY");
        selections.add("BY-I don't care");
        */

        selections.add("AK");
        selections.add("AL");
        selections.add("AR");
        selections.add("AZ");
        selections.add("CA");
        selections.add("CO");
        selections.add("CT");
        selections.add("DC");
        selections.add("DE");
        selections.add("FL");

        selections.add("GA");
        selections.add("HI");
        selections.add("IA");
        selections.add("ID");
        selections.add("IL");
        selections.add("IN");
        selections.add("KS");
        selections.add("KY");
        selections.add("LA");
        selections.add("MA");

        selections.add("MD");
        selections.add("ME");
        selections.add("MI");
        selections.add("MN");
        selections.add("MO");
        selections.add("MS");
        selections.add("MT");
        selections.add("NC");
        selections.add("ND");
        selections.add("NE");

        selections.add("NH");
        selections.add("NJ");
        selections.add("NM");
        selections.add("NV");
        selections.add("NY");
        selections.add("OH");
        selections.add("OK");
        selections.add("OR");
        selections.add("PA");
        selections.add("RI");

        selections.add("SC");
        selections.add("SD");
        selections.add("TN");
        selections.add("TX");
        selections.add("UT");
        selections.add("VA");
        selections.add("WA");
        selections.add("WI");
        selections.add("WV");
        selections.add("WY");
        selections.add("I don't care");

        Question q8 = new Question(title, selections);
        questions.add(q8);

        title = "9 What is your expected annual income after graduation?";
        selections = new ArrayList<>();
        selections.add("A:more than $80,000");
        selections.add("B:$70,000-80,000");
        selections.add("C:$60,000-70,000");
        selections.add("D:$50,000-60,000");
        selections.add("E:I don’t care");

        Question q9 = new Question(title, selections);
        questions.add(q9);

        title = "10 The most important factor in your school decision?";
        selections = new ArrayList<>();
        selections.add("A:Major ranking");
        selections.add("B:Overall ranking");
        selections.add("C:Tuition level");
        selections.add("D:Diversity of student");
        selections.add("E:Possibility of admission");
        selections.add("F:Working situation after graduation");
        selections.add("G:Environment of school");

        Question q10 = new Question(title, selections);
        questions.add(q10);

    }

    private void adapterInit() {
        for(int i = 0; i < questions.size(); i++) {
            QuestionAdapter adapter = new QuestionAdapter(QuestionActivity.this, R.layout.item_selection, questions.get(i).getSelection());
            adapters.add(adapter);
        }
    }


}
