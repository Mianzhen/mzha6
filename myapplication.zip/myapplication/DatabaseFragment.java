package com.example.peter.myapplication;


import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import org.litepal.crud.DataSupport;
import org.litepal.tablemanager.Connector;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * Created by peter on 2016/11/25.
 */

public class DatabaseFragment extends Fragment {
    private View rootView;

    private List<University> universities;
    UniversityAdapter adapter;
    ListView listViewUniversity;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_database, null);

            EditText editTextSearch = (EditText) rootView.findViewById(R.id.edit_search);
            editTextSearch.addTextChangedListener(searchTextWatcher);

            universities = DataSupport.findAll(University.class);
            Collections.sort(universities);
            adapter = new UniversityAdapter(this.getActivity(), (ArrayList) universities);
            listViewUniversity = (ListView) rootView.findViewById(R.id.list_view_university);
            listViewUniversity.setAdapter(adapter);

            listViewUniversity.setOnItemClickListener(universityClickListener);
        } else {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null)
                parent.removeView(rootView);
        }
        return rootView;
    }

    private AdapterView.OnItemClickListener universityClickListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            University university = (University) parent.getItemAtPosition(position);
            int thisId = university.id;

            Intent intent = new Intent(getActivity(), IntroductionActivity.class);
            intent.putExtra("university_id", thisId);
            startActivity(intent);
        }
    };

    private TextWatcher searchTextWatcher = new TextWatcher() {

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            adapter.getFilter().filter(s);
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

}
