package com.example.peter.myapplication;

import android.app.Activity;
import android.content.Context;

import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.PriorityQueue;

public class Algorithm {
    ArrayList<Integer> Final_ID = new ArrayList<Integer>();
    
    public ArrayList<Integer> run(ArrayList<String> answers, Context context) {
        int nSch = 231;
        int n_returned = 15;
        double[] Scores = new double[nSch];
        PriorityQueue<CollegeNameGetter> queue = new PriorityQueue(); //sorting college info based on calculated "distance"
        ArrayList<CollegeFeature> Rec_List = new ArrayList<CollegeFeature>();
        PriorityQueue<CollegeFeature> Sorted_Rec_List = new PriorityQueue<CollegeFeature>();//sorts college based on rank

        ArrayList<CollegeFeature> Final_Rec_List = new ArrayList<CollegeFeature>();
        ArrayList<Integer> Final_ID = new ArrayList<Integer>();
        
        
        String state="";
        double avg_GPA=0;
        double avg_TOEFL=0;
        int avg_SAT=0;
        double tuition_fees=0;
        double median_earning=0;
        
        String ans=answers.get(2);
        String[] tokens=ans.split(":");
        String cmp=tokens[0];
        
        switch(cmp){
            case "A":
                avg_GPA=4.0;
                break;
            case "B":
                avg_GPA=3.9;
                break;
            case "C":
                avg_GPA=3.8;
                break;
            case "D":
                avg_GPA=3.7;
                break;
            case "E":
                avg_GPA=3.6;
                break;
            case "F":
                avg_GPA=3.5;
                break;
            case "G":
                avg_GPA=3.4;
                break;
            case "H":
                avg_GPA=3.3;
                break;
            case "I":
                avg_GPA=3.2;
                break;
            case "J":
                avg_GPA=3.1;
                break;
            case "K":
                avg_GPA=3.0;
                break;
                //if GPA<3
            case "L":
                avg_GPA=2.5;
                break;              
        }
        
         
        ans=answers.get(3);
        tokens=ans.split(":");
        cmp=tokens[0];
         
        switch(cmp){
            case "A":
                avg_SAT=1600;
                break;
            case "B":
                avg_SAT=1550;
                break;
            case "C":
                avg_SAT=1500;
                break;
            case "D":
                avg_SAT=1450;
                break;
            case "E":
                avg_SAT=1400;
                break;
            case "F":
                avg_SAT=1350;
                break;
            case "G":
                avg_SAT=1300;
                break;
            case "H":
                avg_SAT=1250;
                break;
            case "I":
                avg_SAT=1200;
                break;
            case "J":
                avg_SAT=1150;
                break;
            case "K":
                avg_SAT=1100;
                break;
            case "L":
                avg_SAT=1050;
                break;
                //if GPA<1000
            case "M":
                avg_SAT=800;
                break;          
        }
        
        ans=answers.get(4);
        tokens=ans.split(":");
        cmp=tokens[0];
        
        switch(cmp){
            case "A":
                avg_TOEFL=120;
                break;
            case "B":
                avg_TOEFL=115;
                break;
            case "C":
                avg_TOEFL=110;
                break;   
            case "D":
                avg_TOEFL=105;
                break;
            case "E":
                avg_TOEFL=100;
                break;
            case "F":
                avg_TOEFL=95;
                break;
            case "G":
                avg_TOEFL=90;
                break;
            case "H":
                avg_TOEFL=85;
                break;
            case "I":
                avg_TOEFL=80;
                break;
            case "J":
                avg_TOEFL=75;
                break;
            case "K":
                avg_TOEFL=70;
                break;
            case "L":
                avg_TOEFL=65;
                break;
                //if TOEFL<60
            case "M":
                avg_TOEFL=60;
                break;        
        };
        
        ans=answers.get(5);
        tokens=ans.split(":");
        cmp=tokens[0];
        
        switch(cmp){
            case "A": 
                tuition_fees=10000;
                break;
            case "B": 
                tuition_fees=20000;
                break;
            case "C": 
                tuition_fees=25000;
                break;
            case "D": 
                tuition_fees=30000;
                break;
            case "E": 
                tuition_fees=35000;
                break;
            case "F": 
                tuition_fees=40000;
                break;
                //if tuition>40000
            case "G":
                tuition_fees=60000;
        }
        
        ans=answers.get(7);
        //tokens=ans.split("-");
        //cmp=tokens[0];
        cmp=ans;
        switch(cmp){
            case "AK":
                state="AK";
                break;
            case "AL":
                state="AL";
                break;
            case "AR":
                state="AR";
                break;
            case "AZ":
                state="AZ";
                break;
            case "CA":
                state="CA";
                break;
            case "CO":
                state="CO";
                break;
            case "CT":
                state="CT";
                break;
            case "DC":
                state="DC";
                break;
            case "DE":
                state="DE";
                break;
            case "FL":
                state="FL";
                break;
            case "GA":
                state="GA";
                break;
            case "HI":
                state="HI";
                break;
            case "IA":
                state="IA";
                break;
            case "ID":
                state="ID";
                break;
            case "IL":
                state="IL";
                break;
            case "IN":
                state="IN";
                break;
            case "KS":
                state="KS";
                break;
            case "KY":
                state="KY";
                break;
            case "LA":
                state="LA";
                break;
            case "MA":
                state="MA";
                break;
            case "MD":
                state="MD";
                break;
            case "ME":
                state="ME";
                break;
            case "MI":
                state="MI";
                break;
            case "MN":
                state="MN";
                break;
            case "MO":
                state="MO";
                break;
            case "MS":
                state="MS";
                break;
            case "MT":
                state="MT";
                break;
            case "NC":
                state="NC";
                break;
            case "ND":
                state="ND";
                break;
            case "NE":
                state="NE";
                break;
            case "NH":
                state="NH";
                break;
            case "NJ":
                state="NJ";
                break;
            case "NM":
                state="NM";
                break;
            case "NV":
                state="NV";
                break;
            case "NY":
                state="NY";
                break;
            case "OH":
                state="OH";
                break;
            case "OK":
                state="OK";
                break;
            case "OR":
                state="OR";
                break;
            case "PA":
                state="PA";
                break;
            case "RI":
                state="RI";
                break;
            case "SC":
                state="SC";
                break;
            case "SD":
                state="SD";
                break;
            case "TN":
                state="TN";
                break;
            case "TX":
                state="TX";
                break;
            case "UT":
                state="UT";
                break;
            case "VA":
                state="VA";
                break;
            case "WA":
                state="WA";
                break;
            case "WI":
                state="WI";
                break;
            case "WV":
                state="WV";
                break;
            case "WY":
                state="WY";
                break;
            default:
                state="CA";
                break;
        }
        
        ans=answers.get(8);
        tokens=ans.split(":");
        cmp=tokens[0];
        switch(cmp){
            case "A": 
                median_earning=100000;
                break;
            case "B": 
                median_earning=75000;
                break;    
            case "C": 
                median_earning=65000;
                break;
            case "D": 
                median_earning=55000;
                break;
            case "E": 
                median_earning=30000;
                break;
        }
        
        //This is the user input. Change it at your convenience. 
        CollegeFeature user_input = new CollegeFeature(state,avg_GPA,avg_SAT,avg_TOEFL,tuition_fees, median_earning);

        //computes the "distance" in KNN (of the input feature with the features of each college)
        for (int i = 1; i <= nSch; i++) {
            CollegeFeature college = new CollegeFeature(i, context);
            Scores[i - 1] = user_input.compute_score(college);
        }

        /*----------Post-Processing begins------------*/
        //sort colleges by increasing "score". top 30 are first returned
        for (int i = 0; i < Scores.length; i++) {
            CollegeNameGetter info = new CollegeNameGetter(i + 1, Scores[i], context);
            queue.add(info);
        }

        for (int i = 0; i < n_returned; i++) {
            CollegeFeature college = new CollegeFeature(queue.remove().get_ID(), context);
            Sorted_Rec_List.add(college);
            Rec_List.add(college);
        }

        //reach
        for (int i = 0; i < 3; i++) {
            Final_Rec_List.add(Sorted_Rec_List.remove());
        }
        //match
        for (int i = 0; i < Rec_List.size(); i++) {
            if (!Final_Rec_List.contains(Rec_List.get(i))) {
                Final_Rec_List.add(Rec_List.get(i));
            }
            if (Final_Rec_List.size() == 7) {
                break;
            }
        }

        //safety
        CollegeFeature[] temp=Sorted_Rec_List.toArray(new CollegeFeature[0]);
        for(int i=0;i<temp.length;i++){
            CollegeFeature college=temp[temp.length-i-1];
            if(!Final_Rec_List.contains(college)){
                Final_Rec_List.add(college);
            }
            if (Final_Rec_List.size()==10) break;
        }

        for (int i = 0; i < Final_Rec_List.size(); i++) {
            CollegeFeature college=Final_Rec_List.get(i);
            Final_ID.add(college.get_ID());
            college.display();
            //user_input.display_score(college);
        }


        //Final_ID is the arraylist of IDs returned (of size 10). First three-reach, Next four-match, Last three-safety
        return Final_ID;

        
    }
}
