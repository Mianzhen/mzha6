package com.example.peter.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.widget.ImageView;
import android.widget.TextView;

import org.litepal.crud.DataSupport;

import java.text.DecimalFormat;

/**
 * Created by peter on 2016/12/2.
 */

public class IntroductionActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_introduction);

        StatusBarUtils.setWindowStatusBarColor(IntroductionActivity.this, R.color.colorLightBlue);

        Intent intent = getIntent();
        int id = intent.getIntExtra("university_id", 0);
        University university = DataSupport.find(University.class, id);

        ImageView imageScenery = (ImageView)findViewById(R.id.image_scenery);
        imageScenery.setImageResource(university.getScenery());

        ImageView imageBadge = (ImageView)findViewById(R.id.image_badge);
        imageBadge.setImageResource(university.getLogo());

        String name = university.getInstnm();
        String city = university.getCity();
        String state = university.getStabbr();
        String rank = university.getRank();
        String tuition = university.getTuitionFeeOut();
        String earn = university.getMdEarn();
        String accept = university.getAdmRateAll();
        String toefl = university.getToeflMin();
        String sat = university.getSatAvgAll();
        String gpa = university.getGpaAvg();
        String criminal = university.getCriminalRate1();
        String description = university.getLongDescription();

        DecimalFormat df2 = new DecimalFormat("#.00");
        DecimalFormat df3 = new DecimalFormat("#0.00");
        accept = df2.format(Double.parseDouble(accept) * 100);
        criminal = df3.format(Double.parseDouble(criminal) * 100);

        TextView textName = (TextView)findViewById(R.id.text_name);
        TextView textLocation = (TextView)findViewById(R.id.text_location);
        TextView textRank = (TextView)findViewById(R.id.text_rank);
        TextView textTuition = (TextView)findViewById(R.id.text_tuition);
        TextView textEarn = (TextView)findViewById(R.id.text_earn);
        TextView textAccept = (TextView)findViewById(R.id.text_accept);
        TextView textToefl = (TextView)findViewById(R.id.text_toefl);
        TextView textSAT = (TextView)findViewById(R.id.text_sat);
        TextView textGPA = (TextView)findViewById(R.id.text_gpa);
        TextView textCriminal = (TextView)findViewById(R.id.text_criminal);
        TextView textDescription = (TextView)findViewById(R.id.text_description);

        textName.setText(name);
        textLocation.setText("Location: " + city + " " + state);
        textRank.setText("Rank: " + rank);
        textAccept.setText("Acceptance Rate: " + accept + "%");
        textTuition.setText("Tuition: $" + tuition);
        textEarn.setText("Median Income: $" + earn);
        textToefl.setText("Min TOEFL: " + toefl);
        textSAT.setText("Avg SAT: " + sat);
        textGPA.setText("Avg GPA: " + gpa);
        textCriminal.setText("Criminal Rate: " + criminal + "%");
        textDescription.setText(description);

        if(textToefl.getText().equals("Min TOEFL: NULL"))
            textToefl.setText("Min Toefl: No");

        textDescription.setMovementMethod(ScrollingMovementMethod.getInstance()) ;
    }
}
