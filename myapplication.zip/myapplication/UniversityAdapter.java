package com.example.peter.myapplication;


import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by peter on 2016/11/25.
 */

public class UniversityAdapter extends BaseAdapter implements Filterable {

    private Activity activity;
    private UniversityFilter universityFilter;
    private ArrayList<University> universityList;
    private ArrayList<University> filteredList;

    public UniversityAdapter(Activity activity, ArrayList<University> universityList) {
        this.activity = activity;
        this.universityList = universityList;
        this.filteredList = universityList;

        getFilter();
    }

    @Override
    public int getCount() {
        return filteredList.size();
    }

    @Override
    public Object getItem(int position) {
        return filteredList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        University university = (University) getItem(position);
        LayoutInflater layoutInflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = layoutInflater.inflate(R.layout.item_university, parent, false);

        ImageView imageBadge = (ImageView)view.findViewById(R.id.image_list_badge);
        TextView textUniversity = (TextView)view.findViewById(R.id.text_list_name);
        TextView textDescription = (TextView)view.findViewById(R.id.text_list_description);
        TextView textRank = (TextView)view.findViewById(R.id.text_list_rank);

        imageBadge.setImageResource(university.getLogo());
        textUniversity.setText(university.getInstnm());
        textDescription.setText(university.getShortDescription());
        textRank.setText(university.getRank());
        return view;
    }

    @Override
    public Filter getFilter() {
        if (universityFilter == null)
            universityFilter = new UniversityFilter();
        return universityFilter;
    }

    private class UniversityFilter extends Filter {

        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults filterResults = new FilterResults();
            if (constraint!=null && constraint.length()>0) {
                ArrayList<University> tempList = new ArrayList<>();

                // search content in friend list
                for (University university : universityList)
                    if (university.getInstnm().toLowerCase().contains(constraint.toString().toLowerCase()))
                        tempList.add(university);

                filterResults.count = tempList.size();
                filterResults.values = tempList;
            }
            else {
                filterResults.count = universityList.size();
                filterResults.values = universityList;
            }

            return filterResults;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            filteredList = (ArrayList<University>) results.values;
            notifyDataSetChanged();
        }
    }
}
