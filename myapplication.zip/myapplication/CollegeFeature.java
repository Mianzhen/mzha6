
package com.example.peter.myapplication;

import android.app.Activity;
import android.content.Context;

import java.io.*;
import java.util.*;
import java.lang.Math;

public class CollegeFeature implements Comparable<CollegeFeature>{
    private int ID;
    private String schName;
    private String state;
    private int rank;
    private double admit_rate;
    private double avg_GPA;
    private double avg_TOEFL;
    private int avg_SAT;
    private double tuition_fees;
    private double median_earning;
    private double crime_rate;

    //Note that the empty constructor should be interpretted as the user's input, so 
    //there are some info such as "schName" that are redundant. 
    public CollegeFeature(){
        //schName="Random University";
        state="CA";
        //rank=10;//this is the rank of the sch that you want to go to
        //admit_rate=-100;
        avg_GPA=4.0;
        avg_TOEFL=120;
        avg_SAT=1600;
        tuition_fees=60000;
        median_earning=70000;
        //crime_rate=0.03;
    }
    
    public CollegeFeature(String state, double GPA, int SAT, double TOEFL, double tuition, double earning){
        this.state=state;
        this.avg_GPA=GPA;
        this.avg_SAT=SAT;
        this.avg_TOEFL=TOEFL;
        this.median_earning=earning;
        this.tuition_fees=tuition;
        
    }
    
    //// n: ID, or index, of the school, assuming they are arranged from A-Z
    // College_Features(n) contains the feature of the nth school 
    public CollegeFeature(int n, Context context){
        try{

            //File myfile=new File("data2.csv");
            //FileReader myFR=new FileReader(myfile);
            //BufferedReader myBR=new BufferedReader(myfile);

            FileInputStream in = context.openFileInput("data2.csv");
            BufferedReader myBR = new BufferedReader(new InputStreamReader(in));

            String line=myBR.readLine();
            for (int i=0;i<n;i++){
                line=myBR.readLine();
            }
            //System.out.println(line);
            
            String[] tokens=line.split(",");
            ID=(int) Double.parseDouble(tokens[0]);
            schName=tokens[1].replace("\"","");
            state=tokens[3].replace("\"","");
            rank=(int) Double.parseDouble(tokens[4]);
                 
            
            tokens[7]=tokens[7].replace("\"","");
            if(!tokens[7].equals("NULL")){
                admit_rate=Double.parseDouble(tokens[7]);
            }
            else admit_rate=-100;
            
            tokens[8]=tokens[8].replace("\"","");
            if(!tokens[8].equals("NULL")){
                avg_GPA=Double.parseDouble(tokens[8]);
            }
            else avg_GPA=-100;
            
            tokens[9]=tokens[9].replace("\"","");
            if(!tokens[9].equals("NULL")){
                avg_TOEFL=Double.parseDouble(tokens[9]);
            }
            else avg_TOEFL=-100;
           
            tokens[11]=tokens[11].replace("\"","");
            if(!tokens[11].equals("NULL")){
                avg_SAT=(int)Double.parseDouble(tokens[11]);
            }
            else avg_SAT=-100;
            
            tokens[12]=tokens[12].replace("\"","");
            if(!tokens[12].equals("NULL")){
                tuition_fees=Double.parseDouble(tokens[12]);
            }
            else tuition_fees=-100;
            
            tokens[22]=tokens[22].replace("\"","");
            if(!tokens[22].equals("NULL")){
                median_earning=Double.parseDouble(tokens[22]);
            }
            else median_earning=-100;
            
            tokens[23]=tokens[23].replace("\"","");
            if(!tokens[23].equals("NULL")){
                crime_rate=Double.parseDouble(tokens[23]);
            }
            else crime_rate=-100;
            
            
            myBR.close();
            
        }catch(Exception e){
            System.out.println("Error opening file!");
        }
    }
    
    public String get_Name(){
        return schName;
    }
    
    public int get_ID(){
        return ID;  
    }
    
    //prints college info
    public void display(){
        System.out.println("ID: "+ ID + ", School Name: " + schName + ", State: " + state + ", Rank: "+ rank + ", Admission Rate: "+ (double) Math.round(admit_rate*1000)/10 + "%" + ", Average GPA: " + avg_GPA + ", Average TOEFL: "+ avg_TOEFL +", Average SAT: " + avg_SAT +", Tuition Fees: " + tuition_fees + ", Median Earning: " + median_earning + ", Crime Rate: "+ (double) Math.round(crime_rate*10000)/100 +"%");
    }
    
    //distance metric in KNN
    public double compute_score(CollegeFeature college){
        double score=0;
        double GPA_score, SAT_score, TOEFL_score, earning_score;
        
        if (!this.state.equals(college.state)&& college.rank<=30) score+=3;
        else if (!this.state.equals(college.state) && college.rank<=50) score+=2;
        else if (!this.state.equals(college.state) && college.rank>50) score+=0;
        else score+=5;
        
        if(this.crime_rate<0.01) score +=5;
        else if (crime_rate<0.03) score+=2;
        else score+=0;
        
        //computes GPA_score
        if (college.avg_GPA<0) GPA_score=2;
        else{
            if (this.avg_GPA>=college.avg_GPA) {
                if (college.rank<=30) GPA_score=20;
                else {
                    double x=(double)(college.rank-30)/211;
                    GPA_score=20-10*x;
                }
            }
            else GPA_score=10-10*Math.abs(this.avg_GPA-college.avg_GPA);
        }
        if(GPA_score<0) GPA_score=0;
        
        //computes SAT_score
        if (college.avg_SAT<0) SAT_score=2.5;
        else{
            if (this.avg_SAT>=college.avg_SAT) {
                if (college.rank<=30) SAT_score=25;
                else {
                    double x=(double)(college.rank-30)/211;
                    SAT_score=25-10*x;
                }
            }
            else SAT_score=15-10*Math.abs(this.avg_SAT-college.avg_SAT);
        }
        if(SAT_score<0) SAT_score=0;
        
        //computes TOEFL_score
        if (college.avg_TOEFL<0) TOEFL_score=1;
        else{
            if (this.avg_TOEFL>=college.avg_TOEFL) {
                if (college.rank<=30) TOEFL_score=10;
                else {
                    double x=(double)(college.rank-30)/211;
                    TOEFL_score=10-5*x;
                }
            }
            else TOEFL_score=5-10*Math.abs(this.avg_TOEFL-college.avg_TOEFL);
        }
        if(TOEFL_score<0) TOEFL_score=0;
        
        //computes earning_score
        if (college.median_earning<0) earning_score=1;
        else{
            if (this.median_earning<=college.median_earning) {
                if (college.rank<=30) earning_score=10;
                else {
                    double x=(double)(college.rank-30)/211;
                    earning_score=10-5*x;
                }
            }
            else earning_score=5-10*(this.median_earning-college.median_earning);
        }
        if(earning_score<0) earning_score=0;
        
        if(GPA_score==2 || TOEFL_score==1 || SAT_score==2.5){
           
            if (GPA_score==2 && TOEFL_score!=1 && SAT_score!=2.5) {
                double x=20/2;
                TOEFL_score=(1+x/25)*TOEFL_score;
                SAT_score=(1+x/20)*SAT_score;
            }
            else if (GPA_score!=2 && TOEFL_score==1 && SAT_score!=2.5) {
                double x=10/2;
                GPA_score=(1+x/20)*GPA_score;
                SAT_score=(1+x/25)*SAT_score;
            }
            else if(GPA_score!=2 && TOEFL_score!=1 && SAT_score==2.5){
                double x=25/2;
                GPA_score=(1+x/20)*GPA_score;
                TOEFL_score=(1+x/25)*TOEFL_score;
            }
           // else too little info
        }
        
        score+=(GPA_score+TOEFL_score+SAT_score+earning_score);
        
        //System.out.println("Sch: " + college.schName+", SAT score: "+ SAT_score + ", GPA score: "+ GPA_score + ", TOEFL score: "+ TOEFL_score + ", Earning score: " + earning_score);
        
        
    return score;
    }
    
    @Override
    public int compareTo(CollegeFeature otherCollege){
        if (this.rank>otherCollege.rank) return 1;
        if (this.rank<otherCollege.rank) return -1;
        else return 0;
    }
    
}


