package com.example.peter.myapplication;

import android.content.res.Resources;

import org.litepal.crud.DataSupport;

/**
 * Created by peter on 2016/11/24.
 */

public class University extends DataSupport implements Comparable<University>{

    int extraLogo;

    int id;
    int myId;
    String instnm;
    String city;
    String stabbr;
    String rank;
    String latitude;
    String longitude;
    String admRateAll;
    String gpaAvg;
    String toeflAvg;
    String toeflMin;
    String satAvgAll;
    String tuitionFeeOut;
    String ugdsWhite;
    String ugdsBlack;
    String ugdsHisp;
    String ugdsAsian;
    String ugdsAian;
    String ugdsNhpi;
    String ugds2mor;
    String ugdsNra;
    String ugdsUNKN;
    String mdEarn;
    String criminalRate1;
    String shortDescription;
    String longDescription;
    int logo;
    int scenery;

    String rankBuss;
    String randEngin;
    String rankBiosci;
    String rankPhysics;
    String rankChem;
    String rankMath;
    String rankStat;
    String rankCs;
    String rankLaw;
    String rankMed;
    String rankEdu;
    String rankPub;
    String field6;
    String rankPolitics;
    String rankEcon;
    String rankPsych;
    String rankHistory;
    String rankSociology;

    University(){

    }

    University(String[] input1, String[] input2, String input3, String input4, int logo, int scenery) {
        myId = Integer.parseInt(input1[0]);
        instnm = input1[1];
        city = input1[2];
        stabbr = input1[3];
        rank = input1[4];
        latitude = input1[5];
        longitude = input1[6];
        admRateAll = input1[7];
        gpaAvg = input1[8];
        toeflAvg = input1[9];
        toeflMin = input1[10];
        satAvgAll = input1[11];
        tuitionFeeOut = input1[12];
        ugdsWhite = input1[13];
        ugdsBlack = input1[14];
        ugdsHisp = input1[15];
        ugdsAsian = input1[16];
        ugdsAian = input1[17];
        ugdsNhpi = input1[18];
        ugds2mor = input1[19];
        ugdsNra = input1[20];
        ugdsUNKN = input1[21];
        mdEarn = input1[22];
        criminalRate1 = input1[23];

        this.logo = logo;
        this.scenery = scenery;

        shortDescription = input3;
        longDescription = input4;

        rankBuss = input2[2];
        randEngin = input2[3];
        rankBiosci = input2[4];
        rankPhysics = input2[5];
        rankChem = input2[6];
        rankMath = input2[7];
        rankStat = input2[8];
        rankCs = input2[9];
        rankLaw = input2[10];
        rankMed = input2[11];
        rankEdu = input2[12];
        rankPub = input2[13];
        field6 = input2[14];
        rankPolitics = input2[15];
        rankEcon = input2[16];
        rankPsych = input2[17];
        rankHistory = input2[18];
        rankSociology = input2[19];
    }

    public String getAdmRateAll() {
        return admRateAll;
    }

    public void setAdmRateAll(String admRateAll) {
        this.admRateAll = admRateAll;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCriminalRate1() {
        return criminalRate1;
    }

    public void setCriminalRate1(String criminalRate1) {
        this.criminalRate1 = criminalRate1;
    }

    public String getGpaAvg() {
        return gpaAvg;
    }

    public void setGpaAvg(String gpaAvg) {
        this.gpaAvg = gpaAvg;
    }

    public int getId() {
        return myId;
    }

    public void setId(int id) {
        this.myId = id;
    }

    public String getInstnm() {
        return instnm;
    }

    public void setInstnm(String instnm) {
        this.instnm = instnm;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public int getLogo() {
        return logo;
    }

    public void setLogo(int logo) {
        this.logo = logo;
    }

    public String getLongDescription() {
        return longDescription;
    }

    public void setLongDescription(String longDescription) {
        this.longDescription = longDescription;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getMdEarn() {
        return mdEarn;
    }

    public void setMdEarn(String mdEarn) {
        this.mdEarn = mdEarn;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getSatAvgAll() {
        return satAvgAll;
    }

    public void setSatAvgAll(String satAvgAll) {
        this.satAvgAll = satAvgAll;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getStabbr() {
        return stabbr;
    }

    public void setStabbr(String stabbr) {
        this.stabbr = stabbr;
    }

    public String getToeflAvg() {
        return toeflAvg;
    }

    public void setToeflAvg(String toeflAvg) {
        this.toeflAvg = toeflAvg;
    }

    public String getToeflMin() {
        return toeflMin;
    }

    public void setToeflMin(String toeflMin) {
        this.toeflMin = toeflMin;
    }

    public String getTuitionFeeOut() {
        return tuitionFeeOut;
    }

    public void setTuitionFeeOut(String tuitionFeeOut) {
        this.tuitionFeeOut = tuitionFeeOut;
    }

    public String getUgds2mor() {
        return ugds2mor;
    }

    public void setUgds2mor(String ugds2mor) {
        this.ugds2mor = ugds2mor;
    }

    public String getUgdsAian() {
        return ugdsAian;
    }

    public void setUgdsAian(String ugdsAian) {
        this.ugdsAian = ugdsAian;
    }

    public String getUgdsAsian() {
        return ugdsAsian;
    }

    public void setUgdsAsian(String ugdsAsian) {
        this.ugdsAsian = ugdsAsian;
    }

    public String getUgdsBlack() {
        return ugdsBlack;
    }

    public void setUgdsBlack(String ugdsBlack) {
        this.ugdsBlack = ugdsBlack;
    }

    public String getUgdsHisp() {
        return ugdsHisp;
    }

    public void setUgdsHisp(String ugdsHisp) {
        this.ugdsHisp = ugdsHisp;
    }

    public String getUgdsNhpi() {
        return ugdsNhpi;
    }

    public void setUgdsNhpi(String ugdsNhpi) {
        this.ugdsNhpi = ugdsNhpi;
    }

    public String getUgdsNra() {
        return ugdsNra;
    }

    public void setUgdsNra(String ugdsNra) {
        this.ugdsNra = ugdsNra;
    }

    public String getUgdsUNKN() {
        return ugdsUNKN;
    }

    public void setUgdsUNKN(String ugdsUNKN) {
        this.ugdsUNKN = ugdsUNKN;
    }

    public String getUgdsWhite() {
        return ugdsWhite;
    }

    public void setUgdsWhite(String ugdsWhite) {
        this.ugdsWhite = ugdsWhite;
    }

    public String getField6() {
        return field6;
    }

    public void setField6(String field6) {
        this.field6 = field6;
    }

    public String getRandEngin() {
        return randEngin;
    }

    public void setRandEngin(String randEngin) {
        this.randEngin = randEngin;
    }

    public String getRankBiosci() {
        return rankBiosci;
    }

    public void setRankBiosci(String rankBiosci) {
        this.rankBiosci = rankBiosci;
    }

    public String getRankBuss() {
        return rankBuss;
    }

    public void setRankBuss(String rankBuss) {
        this.rankBuss = rankBuss;
    }

    public String getRankChem() {
        return rankChem;
    }

    public void setRankChem(String rankChem) {
        this.rankChem = rankChem;
    }

    public String getRankCs() {
        return rankCs;
    }

    public void setRankCs(String rankCs) {
        this.rankCs = rankCs;
    }

    public String getRankEcon() {
        return rankEcon;
    }

    public void setRankEcon(String rankEcon) {
        this.rankEcon = rankEcon;
    }

    public String getRankEdu() {
        return rankEdu;
    }

    public void setRankEdu(String rankEdu) {
        this.rankEdu = rankEdu;
    }

    public String getRankHistory() {
        return rankHistory;
    }

    public void setRankHistory(String rankHistory) {
        this.rankHistory = rankHistory;
    }

    public String getRankLaw() {
        return rankLaw;
    }

    public void setRankLaw(String rankLaw) {
        this.rankLaw = rankLaw;
    }

    public String getRankMath() {
        return rankMath;
    }

    public void setRankMath(String rankMath) {
        this.rankMath = rankMath;
    }

    public String getRankMed() {
        return rankMed;
    }

    public void setRankMed(String rankMed) {
        this.rankMed = rankMed;
    }

    public String getRankPhysics() {
        return rankPhysics;
    }

    public void setRankPhysics(String rankPhysics) {
        this.rankPhysics = rankPhysics;
    }

    public String getRankPolitics() {
        return rankPolitics;
    }

    public void setRankPolitics(String rankPolitics) {
        this.rankPolitics = rankPolitics;
    }

    public String getRankPsych() {
        return rankPsych;
    }

    public void setRankPsych(String rankPsych) {
        this.rankPsych = rankPsych;
    }

    public String getRankPub() {
        return rankPub;
    }

    public void setRankPub(String rankPub) {
        this.rankPub = rankPub;
    }

    public String getRankSociology() {
        return rankSociology;
    }

    public void setRankSociology(String rankSociology) {
        this.rankSociology = rankSociology;
    }

    public String getRankStat() {
        return rankStat;
    }

    public void setRankStat(String rankStat) {
        this.rankStat = rankStat;
    }

    public int getExtraLogo() {
        return extraLogo;
    }

    public void setExtraLogo(int extraLogo) {
        this.extraLogo = extraLogo;
    }

    public int getMyId() {
        return myId;
    }

    public void setMyId(int myId) {
        this.myId = myId;
    }

    public int getScenery() {
        return scenery;
    }

    public void setScenery(int scenery) {
        this.scenery = scenery;
    }

    @Override
    public int compareTo(University o) {

            int r1 = Integer.parseInt(this.rank);
            int r2 = Integer.parseInt(o.rank);
            if(r1 > r2)
                return 1;
            else if(r1 < r2)
                return -1;
            else
                return 0;

    }
}
