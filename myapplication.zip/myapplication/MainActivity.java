package com.example.peter.myapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.app.FragmentTabHost;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;

import org.litepal.crud.DataSupport;
import org.litepal.tablemanager.Connector;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends FragmentActivity {

    private LayoutInflater layoutInflater;

    private Class fragmentArray[] = { DatabaseFragment.class, RecommendFragment.class, SettingFragment.class };

    private int imageArray[] = { R.drawable.tab_database_btn, R.drawable.tab_recommend_btn, R.drawable.tab_setting_btn };

    private String textArray[] = { "University", "Recommend", "Settings" };

    FragmentTabHost tabHost;

    ArrayList<University> dataSet = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();

        initDatabase();
    }

    private void initView() {
        StatusBarUtils.setWindowStatusBarColor(MainActivity.this, R.color.colorLightBlue);
        layoutInflater = LayoutInflater.from(this);

        tabHost = (FragmentTabHost) findViewById(android.R.id.tabhost);
        tabHost.setup(this, getSupportFragmentManager(), R.id.realtabcontent);

        for (int i = 0; i < 3; i++) {
            TabHost.TabSpec tabSpec = tabHost.newTabSpec(textArray[i]).setIndicator(getTabItemView(i));
            tabHost.addTab(tabSpec, fragmentArray[i], null);
            tabHost.getTabWidget().getChildAt(i).setBackgroundResource(R.drawable.selector_tab_background);
        }
        tabHost.setOnTabChangedListener(onTabChangeListener);
        upDataTab();
    }

    private View getTabItemView(int index) {
        View view = layoutInflater.inflate(R.layout.tab_item_view, null);
        ImageView imageView = (ImageView) view.findViewById(R.id.imageview);
        imageView.setImageResource(imageArray[index]);
        TextView textView = (TextView) view.findViewById(R.id.textview);
        textView.setText(textArray[index]);
        return view;
    }

    private void upDataTab() {
        for (int i = 0; i < tabHost.getTabWidget().getChildCount(); i++) {
            TextView tv = (TextView) tabHost.getTabWidget().getChildAt(i).findViewById(R.id.textview);
            if (tabHost.getCurrentTab() == i)
                tv.setTextColor(getResources().getColor(R.color.colorLightBlue));
            else
                tv.setTextColor(getResources().getColor(android.R.color.darker_gray));
        }
    }

    private TabHost.OnTabChangeListener onTabChangeListener = new TabHost.OnTabChangeListener() {
        @Override
        public void onTabChanged(String tabId) {
            upDataTab();
        }
    };

    private void initDatabase() {
        List test = DataSupport.findAll(University.class);
        if(!test.isEmpty())
            return;

        FileOutputStream out;
        BufferedWriter writer;

        SQLiteDatabase db = Connector.getDatabase();
        DataSupport.deleteAll(University.class);
        try {
            out = openFileOutput("data2.csv", Context.MODE_PRIVATE);
            writer = new BufferedWriter(new OutputStreamWriter(out));
            InputStreamReader inputDataExtra = new InputStreamReader(getAssets().open("data2.csv"));
            BufferedReader bufferDataExtra = new BufferedReader(inputDataExtra);
            String lineExtra;
            while((lineExtra = bufferDataExtra.readLine()) != null)
                writer.write(lineExtra + "\n");
            writer.close();

            InputStreamReader inputData1 = new InputStreamReader(getAssets().open("Data.csv"));
            InputStreamReader inputData2 = new InputStreamReader(getAssets().open("rank.csv"));
            InputStreamReader inputData3 = new InputStreamReader(getAssets().open("short.csv"));
            //InputStreamReader inputData4 = new InputStreamReader(getAssets().open("long.csv"));
            BufferedReader bufferData1 = new BufferedReader(inputData1);
            BufferedReader bufferData2 = new BufferedReader(inputData2);
            BufferedReader bufferData3 = new BufferedReader(inputData3);
            //BufferedReader bufferData4 = new BufferedReader(inputData4);
            String line1;
            String line2;
            String line3;
            String line4;
            bufferData1.readLine();
            bufferData2.readLine();
            bufferData3.readLine();
            //bufferData4.readLine();
            int count = 1;
            while(true){

                line1 = bufferData1.readLine();
                line2 = bufferData2.readLine();
                if(line1 == null || line2 == null)
                    break;

                String[] splits1 = line1.split(",");
                String[] splits2 = line2.split(",");
                line3 = bufferData3.readLine();

                line4 = "";
                InputStreamReader inputData4 = new InputStreamReader(getAssets().open("d (" + count + ").txt"));
                BufferedReader bufferData4 = new BufferedReader(inputData4);
                String temp;
                while((temp = bufferData4.readLine()) != null) {
                    line4 += temp;
                    line4 += "\n";
                }

                String s1 = "a" + splits1[0];
                int logo = this.getResources().getIdentifier(s1, "drawable", "com.example.peter.myapplication");
                String s2 = "s" + splits1[0];
                int scenery = this.getResources().getIdentifier(s2, "drawable", "com.example.peter.myapplication");
                University university = new University(splits1, splits2, line3, line4, logo, scenery);
                dataSet.add(university);

                count++;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        DataSupport.saveAll(dataSet);

    }
}
