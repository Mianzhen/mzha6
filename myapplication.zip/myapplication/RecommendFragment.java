package com.example.peter.myapplication;


import android.support.v4.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;

/**
 * Created by peter on 2016/11/25.
 */

public class RecommendFragment extends Fragment {
    private View rootView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if(rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_recommend, null);

            Button buttonQuestion = (Button) rootView.findViewById(R.id.button_question);
            buttonQuestion.setOnClickListener(buttonQuestionOnClickListener);
        }
        else {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null)
                parent.removeView(rootView);
        }
        return rootView;
    }

    private View.OnClickListener buttonQuestionOnClickListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            Intent intent = new Intent(getActivity(), QuestionActivity.class);
            startActivity(intent);
        }
    };
}
