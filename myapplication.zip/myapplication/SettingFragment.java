package com.example.peter.myapplication;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.util.ArrayList;

/**
 * Created by peter on 2016/11/26.
 */

public class SettingFragment extends Fragment {
    private View rootView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if(rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_setting, null);
            Button buttonHistory = (Button) rootView.findViewById(R.id.button_history);
            buttonHistory.setOnClickListener(buttonHistoryOnClickListener);
            Button buttonAbout = (Button) rootView.findViewById(R.id.button_about);
            buttonAbout.setOnClickListener(buttonAboutOnClickListener);
        }
        else {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null)
                parent.removeView(rootView);
        }
        return rootView;
    }

    private View.OnClickListener buttonHistoryOnClickListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            ArrayList<Integer> temp = new ArrayList();
            FileInputStream in = null;
            BufferedReader reader = null;
            StringBuilder content = new StringBuilder();
            try {
                in = getContext().openFileInput("record.txt");
                reader = new BufferedReader(new InputStreamReader(in));
                for(int i = 0; i < 10; i++)
                    temp.add(reader.read());
                reader.close();

                Intent intent = new Intent(getActivity(), ResultActivity.class);
                intent.putExtra("recommend_result", temp);
                startActivity(intent);
            } catch (IOException e) {
                Toast.makeText(getActivity(), "No history record!", Toast.LENGTH_SHORT).show();
            }

        }
    };

    private View.OnClickListener buttonAboutOnClickListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            String aboutContext = "Easy College Decision\n\nVersion：v1.0\n@ 2016 Hi6242 All Rights Reserved";
            Dialog dialog = new AlertDialog.Builder(getActivity()).
                    setIcon(R.drawable.ic_launcher).
                    setTitle("About").
                    setMessage(aboutContext).
                    setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub
                            dialog.cancel();
                        }
                    }).
                    create();
            dialog.show();
        }
    };
}
