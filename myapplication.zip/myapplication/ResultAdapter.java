package com.example.peter.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by peter on 2016/12/2.
 */

public class ResultAdapter extends ArrayAdapter<University> {
    private int resourceId;


    public ResultAdapter(Context context, int resource, List<University> objects) {
        super(context, resource, objects);
        resourceId = resource;
    }

    @Override public View getView(int position, View convertView, ViewGroup parent) {
        University university = getItem(position);
        View view = LayoutInflater.from(getContext()).inflate(resourceId,null);

        ImageView imageBadge = (ImageView)view.findViewById(R.id.image_list2_badge);
        TextView textUniversity = (TextView)view.findViewById(R.id.text_list2_name);
        ImageView imageMedal = (ImageView)view.findViewById(R.id.image_list2_medal);

        imageBadge.setImageResource(university.getLogo());
        textUniversity.setText(university.getInstnm());
        imageMedal.setImageResource(university.getExtraLogo());
        return view;
    }

}
