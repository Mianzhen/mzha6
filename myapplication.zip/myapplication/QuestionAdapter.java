package com.example.peter.myapplication;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by peter on 2016/11/23.
 */

public class QuestionAdapter extends ArrayAdapter<String> {
    private int resourceId;

    public QuestionAdapter(Context context, int resource, List<String> objects) {
        super(context, resource, objects);
        this.resourceId = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        String selection = getItem(position);
        View view = LayoutInflater.from(getContext()).inflate(resourceId,null);
        TextView textSelection = (TextView)view.findViewById(R.id.text_selection);
        textSelection.setText(selection);
        if(position % 2 == 0)
            view.setBackgroundColor(Color.argb(0x1f, 0x00, 0x00, 0x00));
        else
            view.setBackgroundColor(Color.argb(0x1f, 0xdf, 0xdf, 0xdf));

        return view;
    }
}
