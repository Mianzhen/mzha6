
package com.example.peter.myapplication;


import android.app.Activity;
import android.content.Context;

import java.io.*;

public class CollegeNameGetter implements Comparable<CollegeNameGetter>{
    int ID;
    double score;
    String name;
    
    public int get_ID(){return ID;}
    
    public CollegeNameGetter(int ID, double diff, Context context){
        this.ID=ID;
        this.score=diff;

        int nSch=231;
         try{
             //File myfile=new File("data2.csv");
             //FileReader myFR=new FileReader(myfile);
             //BufferedReader myBR=new BufferedReader(myFR);

             FileInputStream in = context.openFileInput("data2.csv");
             BufferedReader myBR = new BufferedReader(new InputStreamReader(in));
            
             String line;
             line=myBR.readLine();
             for(int i=1;i<nSch+1;i++){
                line=myBR.readLine();
                String[] tokens=line.split(",");
                if (this.ID==(int)Double.parseDouble(tokens[0])){
                    this.name=tokens[1].replace("\"","");
                }
            }
            
            myBR.close();
            
         }catch(Exception e){
             System.out.println("Error opening file!");
         }
    }
    
    public void print(){
        System.out.println("ID: " + ID + ", Name:" + name + ", Score: "+ score);
    }
    
    @Override
    public int compareTo(CollegeNameGetter otherCollege){
        if (this.score>otherCollege.score) return -1;
        else if (this.score<otherCollege.score) return 1;
        else return 0;
    }
    
    
    
}
