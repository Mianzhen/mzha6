package com.example.peter.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.media.MediaBrowserServiceCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import org.litepal.crud.DataSupport;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by peter on 2016/12/2.
 */

public class ResultActivity extends AppCompatActivity {

    List<University> resultReach;
    List<University> resultMatch;
    List<University> resultSafety;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        initView();
    }

    private void initView() {
        StatusBarUtils.setWindowStatusBarColor(ResultActivity.this, R.color.colorLightBlue);

        Intent intent = getIntent();
        ArrayList<Integer> resultId = intent.getIntegerArrayListExtra("recommend_result");
        ArrayList<University> result = new ArrayList<>();
        for(int i = 0; i < 10; i++) {
            University u = DataSupport.find(University.class, resultId.get(i));
            result.add(u);
        }
        result.get(0).setExtraLogo(R.drawable.gold);
        result.get(1).setExtraLogo(R.drawable.silver);
        result.get(2).setExtraLogo(R.drawable.bronze);
        result.get(3).setExtraLogo(R.drawable.place4);
        result.get(4).setExtraLogo(R.drawable.place5);
        result.get(5).setExtraLogo(R.drawable.place6);
        result.get(6).setExtraLogo(R.drawable.place7);
        result.get(7).setExtraLogo(R.drawable.place8);
        result.get(8).setExtraLogo(R.drawable.place9);
        result.get(9).setExtraLogo(R.drawable.place10);

        resultReach = result.subList(0, 3);
        resultMatch = result.subList(3, 7);
        resultSafety = result.subList(7, 10);

        ResultAdapter adapterReach = new ResultAdapter(ResultActivity.this, R.layout.item_result, resultReach);
        ResultAdapter adapterMatch = new ResultAdapter(ResultActivity.this, R.layout.item_result, resultMatch);
        ResultAdapter adapterSafety = new ResultAdapter(ResultActivity.this, R.layout.item_result, resultSafety);

        ScrollViewWithListView listViewReach = (ScrollViewWithListView) findViewById(R.id.list_view_result_reach);
        ScrollViewWithListView listViewMatch = (ScrollViewWithListView) findViewById(R.id.list_view_result_match);
        ScrollViewWithListView listViewSafety = (ScrollViewWithListView) findViewById(R.id.list_view_result_safety);

        listViewReach.setAdapter(adapterReach);
        listViewMatch.setAdapter(adapterMatch);
        listViewSafety.setAdapter(adapterSafety);

        listViewReach.setOnItemClickListener(reachClickListener);
        listViewMatch.setOnItemClickListener(matchClickListener);
        listViewSafety.setOnItemClickListener(safetyClickListener);
    }

    private AdapterView.OnItemClickListener reachClickListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            University university = resultReach.get(position);
            int thisId = university.id;

            Intent intent = new Intent(ResultActivity.this, IntroductionActivity.class);
            intent.putExtra("university_id", thisId);
            startActivity(intent);
        }
    };

    private AdapterView.OnItemClickListener matchClickListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            University university = resultMatch.get(position);
            int thisId = university.id;

            Intent intent = new Intent(ResultActivity.this, IntroductionActivity.class);
            intent.putExtra("university_id", thisId);
            startActivity(intent);
        }
    };

    private AdapterView.OnItemClickListener safetyClickListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            University university = resultSafety.get(position);
            int thisId = university.id;

            Intent intent = new Intent(ResultActivity.this, IntroductionActivity.class);
            intent.putExtra("university_id", thisId);
            startActivity(intent);
        }
    };

}
